import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class EmotionService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<void> recordEmotion({
    required String studentUid,
    required String emotion,
    String? note,
  }) async {
    final now = DateTime.now().toUtc();
    final dayKey = DateFormat('yyyy-MM-dd').format(now);
    await _db
        .collection('students')
        .doc(studentUid)
        .collection('emotions')
        .add({
      'emotion': emotion,
      'note': note,
      'createdAt': now,
      'dayKey': dayKey,
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> watchStudentEmotions(String studentUid) {
    return _db
        .collection('students')
        .doc(studentUid)
        .collection('emotions')
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> watchCourseStudents(String course) {
    return _db
        .collection('users')
        .where('role', isEqualTo: 'estudiante')
        .where('course', isEqualTo: course)
        .snapshots();
  }
}


