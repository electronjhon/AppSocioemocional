import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../providers/session_provider.dart';
import '../../services/emotion_service.dart';
import '../../services/auth_service.dart';
import '../../widgets/gradient_background.dart';

class TeacherHomeScreen extends StatelessWidget {
  const TeacherHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionProvider>();
    final user = session.profile!;
    final emotionService = EmotionService();

    return Scaffold(
      appBar: AppBar(
        title: Text('Hola, ${user.firstName} ${user.lastName}'),
        actions: [
          IconButton(
            tooltip: 'Cerrar sesión',
            icon: const Icon(Icons.logout),
            onPressed: () async => AuthService().signOut(),
          ),
        ],
      ),
      body: GradientBackground(
        child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text('Curso: ${user.course}', style: Theme.of(context).textTheme.titleMedium),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: emotionService.watchCourseStudents(user.course),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final students = snapshot.data!.docs;
                if (students.isEmpty) {
                  return const Center(child: Text('Sin estudiantes registrados'));
                }
                return ListView.separated(
                  itemBuilder: (_, i) {
                    final s = students[i].data();
                    return ListTile(
                      title: Text('Doc: ${s['documentId']}'),
                      subtitle: Text('Curso: ${s['course']}'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => _StudentDetailScreen(
                              studentUid: s['uid'] as String,
                              documentId: s['documentId'] as String,
                            ),
                          ),
                        );
                      },
                    );
                  },
                  separatorBuilder: (_, __) => const Divider(),
                  itemCount: students.length,
                );
              },
            ),
          ),
        ],
      ),
    ),
  );
  }
}

class _StudentDetailScreen extends StatelessWidget {
  final String studentUid;
  final String documentId;
  const _StudentDetailScreen({required this.studentUid, required this.documentId});

  @override
  Widget build(BuildContext context) {
    final emotionService = EmotionService();
    return Scaffold(
      appBar: AppBar(title: Text('Estudiante $documentId')),
      body: GradientBackground(
        child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: emotionService.watchStudentEmotions(studentUid),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final docs = snapshot.data!.docs;
            if (docs.isEmpty) return const Center(child: Text('Sin registros'));

            final Map<String, int> counts = {};
            for (final d in docs) {
              final emotion = (d.data()['emotion'] as String);
              counts.update(emotion, (v) => v + 1, ifAbsent: () => 1);
            }
            final sections = counts.entries.map((e) => PieChartSectionData(
                  color: _colorForEmotion(e.key),
                  value: e.value.toDouble(),
                  title: e.key,
                  radius: 48,
                  titleStyle: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                )).toList();

            return Column(
              children: [
                const SizedBox(height: 12),
                SizedBox(
                  height: 220,
                  child: Card(
                    elevation: 3,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: PieChart(PieChartData(sections: sections, sectionsSpace: 2, centerSpaceRadius: 24)),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: ListView.separated(
                    itemBuilder: (_, i) {
                      final data = docs[i].data();
                      return ListTile(
                        leading: CircleAvatar(backgroundColor: _colorForEmotion(data['emotion'] as String)),
                        title: Text(data['emotion'] as String),
                        subtitle: Text((data['createdAt'] as Timestamp).toDate().toLocal().toString()),
                      );
                    },
                    separatorBuilder: (_, __) => const Divider(),
                    itemCount: docs.length,
                  ),
                )
              ],
            );
          },
        ),
      ),
    );
  }

  Color _colorForEmotion(String emotion) {
    switch (emotion.toLowerCase()) {
      case 'feliz':
        return Colors.orangeAccent;
      case 'triste':
        return Colors.blueAccent;
      case 'enojado':
        return Colors.redAccent;
      case 'ansioso':
        return Colors.purpleAccent;
      case 'calmado':
        return Colors.greenAccent;
      default:
        return Colors.teal;
    }
  }
}


