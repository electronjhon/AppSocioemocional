import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../providers/session_provider.dart';
import '../../services/emotion_service.dart';
import '../../services/auth_service.dart';
import '../../widgets/gradient_background.dart';

class StudentHomeScreen extends StatefulWidget {
  const StudentHomeScreen({super.key});

  @override
  State<StudentHomeScreen> createState() => _StudentHomeScreenState();
}

class _StudentHomeScreenState extends State<StudentHomeScreen> {
  final _emotions = const ['Feliz', 'Triste', 'Enojado', 'Ansioso', 'Calmado'];
  String? _selected;
  final EmotionService _emotionService = EmotionService();

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionProvider>();
    final user = session.profile!;
    return Scaffold(
      appBar: AppBar(
        title: Text('Hola, ${user.firstName} ${user.lastName}'),
        actions: [
          IconButton(
            tooltip: 'Cerrar sesión',
            icon: const Icon(Icons.logout),
            onPressed: () async => AuthService().signOut(),
          ),
        ],
      ),
      body: GradientBackground(
        child: Padding(
          padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('¿Cómo te sientes hoy?'),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: _emotions.map((e) {
                final selected = _selected == e;
                return ChoiceChip(
                  label: Text(e),
                  selected: selected,
                  onSelected: (_) => setState(() => _selected = e),
                );
              }).toList(),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _selected == null
                  ? null
                  : () async {
                      await _emotionService.recordEmotion(
                        studentUid: user.uid,
                        emotion: _selected!,
                      );
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Emoción registrada')),
                        );
                      }
                    },
              child: const Text('Registrar emoción'),
            ),
            const Divider(height: 32),
            const Text('Historial'),
            const SizedBox(height: 8),
            Expanded(
              child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: _emotionService.watchStudentEmotions(user.uid),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  final docs = snapshot.data!.docs;
                  if (docs.isEmpty) {
                    return const Center(child: Text('Sin registros'));
                  }

                  // Conteo para gráfica circular
                  final Map<String, int> counts = {};
                  for (final d in docs) {
                    final emotion = (d.data()['emotion'] as String);
                    counts.update(emotion, (v) => v + 1, ifAbsent: () => 1);
                  }
                  final sections = counts.entries.map((e) {
                    final color = _colorForEmotion(e.key);
                    return PieChartSectionData(
                      color: color,
                      value: e.value.toDouble(),
                      title: e.key,
                      radius: 48,
                      titleStyle: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                    );
                  }).toList();

                  return Column(
                    children: [
                      SizedBox(
                        height: 220,
                        child: Card(
                          elevation: 3,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: PieChart(PieChartData(sections: sections, sectionsSpace: 2, centerSpaceRadius: 24)),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Expanded(
                        child: ListView.separated(
                          itemBuilder: (_, i) {
                            final data = docs[i].data();
                            return ListTile(
                              leading: CircleAvatar(backgroundColor: _colorForEmotion(data['emotion'] as String)),
                              title: Text(data['emotion'] as String),
                              subtitle: Text((data['createdAt'] as Timestamp).toDate().toLocal().toString()),
                            );
                          },
                          separatorBuilder: (_, __) => const Divider(),
                          itemCount: docs.length,
                        ),
                      ),
                    ],
                  );
                },
              ),
            )
          ],
        ),
      ),
    ),
  );
  }

  Color _colorForEmotion(String emotion) {
    switch (emotion.toLowerCase()) {
      case 'feliz':
        return Colors.orangeAccent;
      case 'triste':
        return Colors.blueAccent;
      case 'enojado':
        return Colors.redAccent;
      case 'ansioso':
        return Colors.purpleAccent;
      case 'calmado':
        return Colors.greenAccent;
      default:
        return Colors.teal;
    }
  }
}


