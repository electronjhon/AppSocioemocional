package com.example.appsocioemocional

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
